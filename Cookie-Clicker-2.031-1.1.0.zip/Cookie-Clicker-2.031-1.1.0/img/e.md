de
